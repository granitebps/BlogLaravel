<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>Website MyMind Membuat Post Baru Yang Berjudul {{$post}}</p>
    <p>Link Untuk Langsung Menuju Post : https://localhost:8000/post/{{$slug}} </p>
</body>
</html>