<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>Anda Telah Mengirim Pesan Ke Website MyMind Yang Berisi : </p>
    <p>{{$body}}</p>
    <p>===============================================================================================================================================</p>
    <p>{{$msg}}</p>
</body>
</html>