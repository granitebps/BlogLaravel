<?php $__env->startSection('content'); ?>
    <h1 class="page-header">Message</h1>
    <div class="row">
        <div class="panel panel-warning">
            <div class="panel-heading">Message List</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Message</th>
                                <th>Created At</th>
                                <th>Readed</th>
                                <th colspan="3" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($message->count() > 0): ?>

                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->msg_name); ?></td>
                                    <td><?php echo e($row->msg_email); ?></td>
                                    <td><?php echo e($row->msg_body); ?></td>
                                    <td><?php echo e(date('j F Y', strtotime($row->created_at))); ?></td>
                                    <td>
                                        <?php if($row->readed == 1): ?>
                                            Readed
                                        <?php else: ?>
                                            UnRead
                                        <?php endif; ?>
                                    </td>
                                    <td width="80px" class="text-center">
                                        <a href="<?php echo e(route('message.reply', ['id'=>$row->msg_id])); ?>" class="btn btn-primary">Reply</a></td>
                                    <td width="90px" class="text-center">
                                        <a href="<?php echo e(route('message.delete', ['id'=>$row->msg_id])); ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                    <td width="100px" class="text-center">
                                        <?php if($row->readed == 1): ?>
                                            <a href="<?php echo e(route('message.read', ['id'=>$row->msg_id])); ?>" class="btn btn-default">Mark As UnRead</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('message.read', ['id'=>$row->msg_id])); ?>" class="btn btn-default">Mark As Read</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-danger">No message Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo e($message->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>