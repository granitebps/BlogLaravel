<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="page-heading">Tag</h1>
        <div class="panel panel-red">
            <div class="panel-heading">Tag List</div>
            <div class="panel-body">
                <div class="table-resposive">
                    <table class="table table-hovered">
                        <thead>
                            <tr>
                                <th>Tag Name</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($tag->count() > 0): ?>
                            <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->tag_name); ?></td>
                                <td><a href="<?php echo e(route('tag.edit', ['id'=>$row->tag_id])); ?>" class="btn btn-primary">Edit</a></td>
                                <td>
                                    <form action="<?php echo e(route('tag.destroy', ['id'=>$row->tag_id])); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center text-danger">No Tag Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>