<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="page-heading">Post</h1>
        <div class="panel panel-primary">
            <div class="panel-heading">Trashed Post List</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hovered">
                        <thead>
                            <tr>
                                <th>Post Title</th>
                                <th>Category</th>
                                <th>Tag</th>
                                <th>Created At</th>
                                <th>Deleted At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($post->count() > 0): ?>

                            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->post_title); ?></td>
                                    <td><?php echo e($row->category->category_name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $row->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag->tag_name. ', '); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($row->created_at); ?></td>
                                    <td><?php echo e($row->deleted_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('post.restored', ['id'=>$row->post_id])); ?>" class="btn btn-success">Restore</a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('post.killed', ['id'=>$row->post_id])); ?>" class="btn btn-danger tombol-hapus">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-danger">No Trashed Post Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $('.tombol-hapus').on('click', function(e){
            e.preventDefault();
            const href = $(this).attr('href');
            Swal({
                title: 'Apakah Anda Yakin Ingin Menghapus Post Ini Secara Permanent?',
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!'
            }).then((result) => {
                if (result.value) {
                    document.location.href = href;
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>