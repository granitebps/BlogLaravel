<?php $__env->startSection('content'); ?>
    <h1 class="page-header">Task</h1>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-yellow">
                <div class="panel-heading">
                    Task List
                </div>
                <div class="panel-body">
                    <a href="<?php echo e(route('task.create')); ?>" class="btn btn-lg btn-default">Create Task</a>
                    <div class="table-resposive">
                        <table class="table table-hovered">
                            <thead>
                                <tr>
                                    <th>Task</th>
                                    <th>Created At</th>
                                    <th>Deadline</th>
                                    <th colspan="3" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->task); ?></td>
                                        <td><?php echo e(date('l d F Y', strtotime($row->created_at))); ?></td>
                                        <td><?php echo e(date('l d F Y', strtotime($row->deadline))); ?></td>
                                        <?php if(!$row->completed): ?>
                                        <td>
                                            <a href="<?php echo e(route('task.edit', ['id'=> $row->id])); ?>" class="btn btn-primary">Edit Task</a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('task.completed', ['id' => $row->id])); ?>" class="btn btn-success">Completed</a>
                                        </td>
                                        <?php else: ?>
                                        <td colspan="2" class="text-center text-success">COMPLETED</td>
                                        <?php endif; ?>
                                        <td>
                                            <form action="<?php echo e(route('task.destroy', ['id'=> $row->id])); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>