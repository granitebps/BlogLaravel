<?php $__env->startSection('content'); ?>
    <h1 class="page-header">User</h1>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-info">
                <div class="panel-heading">
                    User List
                </div>
                <div class="panel-body">
                    <div class="table-resposive">
                        <table class="table table-hovered">
                            <thead>
                                <tr>
                                    <th>Avatar</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Created At</th>
                                    <th>Permission</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td><img src="<?php echo e(asset('storage/images/avatars/'.$row->profile->avatar)); ?>" width="100px" height="100px"></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td><?php echo e($row->created_at->toformattedDateString()); ?></td>
                                    <td>
                                        <?php if($row->admin==1): ?>
                                            <a href="#" class="btn btn-lg btn-success">Admin</a>
                                        <?php else: ?>
                                        <a href="#" class="btn btn-lg btn-danger">Not Admin</a>
                                        <?php endif; ?>
                                    </td>
                                    <?php if($row->id!=Auth::id()): ?>
                                    <td>
                                        <a href="<?php echo e(route('user.delete', ['id'=>$row->id])); ?>" class="btn btn-lg btn-danger">Trash</a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>