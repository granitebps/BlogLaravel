<?php $__env->startSection('content'); ?>
    
    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--top-padding s-content--narrow">

        <article class="row entry format-standard">

            <div class="entry__media col-full">
                <div class="entry__post-thumb">
                    <a target="_blank" href="<?php echo e(asset('storage/images/posts/'.$post->featured)); ?>">
                    <img src="<?php echo e(asset('storage/images/posts/'.$post->featured)); ?>" 
                        srcset="<?php echo e(asset('storage/images/posts/'.$post->featured)); ?> 2000w, 
                                <?php echo e(asset('storage/images/posts/'.$post->featured)); ?> 1000w, 
                                <?php echo e(asset('storage/images/posts/'.$post->featured)); ?> 500w" 
                        sizes="(max-width: 2000px) 100vw, 2000px" alt="">
                    </a>
                </div>
            </div>

            <div class="entry__header col-full">
                <h1 class="entry__header-title display-1">
                    <?php echo e($post->post_title); ?>

                </h1>
                <ul class="entry__header-meta">
                    <li class="date"><?php echo e($post->created_at->toFormattedDateString()); ?></li>
                    <li class="byline">
                        By
                        <a href="#"><?php echo e($post->user->name); ?></a>
                    </li>
                </ul>
            </div>

            <div class="col-full entry__main">

                <p><?php echo $post->post_content; ?></p>

                <div class="entry__taxonomies">
                    <div class="entry__cat">
                        <h5>Posted In: </h5>
                        <span class="entry__tax-list">
                            <a href="<?php echo e(route('home.category', ['slug'=>$post->category->category_slug])); ?>"><?php echo e($post->category->category_name); ?></a>
                        </span>
                    </div> <!-- end entry__cat -->

                    <div class="entry__tags">
                        <h5>Tags: </h5>
                        <span class="entry__tax-list entry__tax-list--pill">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('home.tag', ['slug'=>$item->tag_slug])); ?>"><?php echo e($item->tag_name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </span>
                    </div> <!-- end entry__tags -->
                </div> <!-- end s-content__taxonomies -->

                Share This Post : 
                <!-- Go to www.addthis.com/dashboard to customize your tools -->
                <div class="addthis_inline_share_toolbox"></div>
            

                <div class="entry__author">
                    <img src="<?php echo e(asset('storage/images/avatars/'.$post->profile->avatar)); ?>" alt="">

                    <div class="entry__author-about">
                        <h5 class="entry__author-name">
                            <span>Posted by</span>
                            <a href="#"><?php echo e($post->user->name); ?></a>
                        </h5>

                        <div class="entry__author-desc">
                            <p>
                            <?php echo e($post->profile->user_about); ?>

                            </p>
                        </div>
                    </div>
                </div>

            </div> <!-- s-entry__main -->

        </article> <!-- end entry/article -->


        <div class="s-content__entry-nav">
            <div class="row s-content__nav">
                <?php if($prev_post): ?>
                <div class="col-six s-content__prev">
                    <a href="<?php echo e(route('home.show', ['slug'=>$prev_post->post_slug])); ?>" rel="prev">
                        <span>Previous Post</span>
                        <?php echo e($prev_post->post_title); ?>

                    </a>
                </div>
                <?php endif; ?>
                <?php if($next_post): ?>
                <div class="col-six s-content__next">
                    <a href="<?php echo e(route('home.show', ['slug'=>$next_post->post_slug])); ?>" rel="next">
                        <span>Next Post</span>
                        <?php echo e($next_post->post_title); ?>

                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div> <!-- end s-content__pagenav -->

        <div class="comments-wrap">

            <div id="comments" class="row">
                <div class="col-full">
                    <h3 class="h2">Comments</h3>
                    <?php echo $__env->make('layouts.disqus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div> <!-- end col-full -->
            </div> <!-- end comments -->

        </div> <!-- end comments-wrap -->

    </section> <!-- end s-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>