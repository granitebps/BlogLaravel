<?php $__env->startSection('content'); ?>
    
<h1 class="page-header">Profile</h1>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Edit Profile
            </div>
            <div class="panel-body">
                <form action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" type="text" value="<?php echo e($user->name); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" type="email" value="<?php echo e($user->email); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Avatar | Max : 2 MB | Width : 100px | Height : 100px</label><br>
                        <img src="<?php echo e(asset($user->profile->avatar)); ?>" width="100px" height="100px">
                        <input name="avatar" type="file" class="form-control-file">
                    </div>
                    <div class="form-group">
                        <label>About</label>
                        <textarea name="user_about" cols="30" rows="10" class="form-control"><?php echo e($user->profile->user_about); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" class="form-control" cols="30" rows="10" required><?php echo e($user->profile->address); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Contact Number</label>
                        <input type="text" name="contact_number" value="<?php echo e($user->profile->contact_number); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Contact Email</label>
                        <input type="email" name="contact_email" value="<?php echo e($user->profile->contact_email); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Instagram</label>
                        <input type="text" name="instagram" value="<?php echo e($user->profile->instagram); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Facebook</label>
                        <input type="text" name="facebook" value="<?php echo e($user->profile->facebook); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Twitter</label>
                        <input type="text" name="twitter" value="<?php echo e($user->profile->twitter); ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>LinkedIn</label>
                        <input type="text" name="linkedin" value="<?php echo e($user->profile->linkedin); ?>" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-lg btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>