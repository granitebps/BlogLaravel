<?php $__env->startSection('content'); ?>

    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--top-padding">

        <div class="row narrow">
            <div class="col-full s-content__header" data-aos="fade-up">
                <h1 class="display-1 display-1--with-line-sep">My Portfolio</h1>
            </div>
        </div>
        
        <div class="row">
            <div class="col-full s-content__main">
                <div class="table-responsive">

                    <table>
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Desciption</th>
                                <th>Link To Github</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="250px">
                                        <a target="_blank" href="<?php echo e(asset('storage/images/portfolio/'.$row->portfolio_image)); ?>">
                                            <img src="<?php echo e(asset('storage/images/portfolio/'.$row->portfolio_image)); ?>" alt="" height="160px" width="240px">
                                        </a>
                                    </td>
                                    <td><?php echo e($row->portfolio_name); ?></td>
                                    <td><?php echo $row->portfolio_desc; ?></td>
                                    <td width="180px"><a target="_blank" href="<?php echo e($row->portfolio_url); ?>"><i class="fab fa-github"></i> <?php echo e($row->portfolio_name); ?></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div> <!-- s-content__main -->
        </div> <!-- end row -->

    </section> <!-- end s-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>