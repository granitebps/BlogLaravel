<?php $__env->startSection('content'); ?>
    <h1 class="page-header">Setting</h1>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-green">
                <div class="panel-heading">
                    Edit Site Setting
                </div>
                <div class="panel-body">
                    <form action="<?php echo e(route('setting.update')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label>Site Name</label>
                            <input name="site_name" type="text" value="<?php echo e($errors->isEmpty() ? $setting->site_name : old('site_name')); ?>" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Site About</label>
                            <textarea id="article-ckeditor" name="about" cols="30" rows="10" class="form-control" required><?php echo e($errors->isEmpty() ? $setting->about : old('about')); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-block btn-success">Edit</button>
                    </form>
                    <hr>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning btn-block">Back</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var options = {
            filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
            filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
            height: '700px',
            extraPlugins: 'codesnippet,iframe',
        };
        CKEDITOR.replace( 'article-ckeditor', options);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>