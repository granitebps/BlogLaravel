<?php $__env->startSection('content'); ?>
    <h1 class="page-heading">
        Category
    </h1>
    <div class="row">
        <div class="panel panel-success">
            <div class="panel-heading">Edit Category : <?php echo e($category->category_name); ?></div>
            <div class="panel-body">
                <form action="<?php echo e(route('category.update', ['id'=>$category->category_id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label for="">Category Name</label>
                        <input type="text" name="category_name" class="form-control" value="<?php echo e($errors->isEmpty() ? $category->category_name : old('category_name')); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-success btn-block">Edit</button>
                </form>
                <hr>
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-warning btn-block">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>