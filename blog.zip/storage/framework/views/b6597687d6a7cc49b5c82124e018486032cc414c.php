<?php $__env->startSection('content'); ?>
    <h1 class="page-header">Portfolio</h1>
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Portfolio List</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Link</th>
                                <th colspan="2" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($portfolio->count() > 0): ?>
                            <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="250px"><img src="<?php echo e(asset('storage/images/portfolio/'.$row->portfolio_image)); ?>" alt="" width="240px" height="160px"></td>
                                <td><?php echo e($row->portfolio_name); ?></td>
                                <td><?php echo $row->portfolio_desc; ?></td>
                                <td width="250px"><?php echo e($row->portfolio_url); ?></td>
                                <td width="80px">
                                    <a href="<?php echo e(route('portfolio.edit', ['id'=>$row->portfolio_id])); ?>" class="btn btn-primary">Edit</a>
                                </td>
                                <td width="100px">
                                    <form action="<?php echo e(route('portfolio.destroy', ['id'=>$row->portfolio_id])); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center text-danger">No Portfolio Found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>