<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>Anda Telah Mengirim Pesan Ke Website MyMind Yang Berisi : </p>
    <p><?php echo e($body); ?></p>
    <p>===============================================================================================================================================</p>
    <p><?php echo e($msg); ?></p>
</body>
</html>