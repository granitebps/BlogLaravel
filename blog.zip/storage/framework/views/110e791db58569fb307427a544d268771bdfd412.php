<?php $__env->startSection('content'); ?>
    <h1 class="page-heading">
        Message
    </h1>
    <div class="row">
        <div class="panel panel-warning">
            <div class="panel-heading">Reply Message</div>
            <div class="panel-body">
                <form action="<?php echo e(route('message.replied', ['id'=>$message->msg_id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="">Name : </label>
                        <?php echo e($message->msg_name); ?>

                    </div>

                    <div class="form-group">
                        <label for="">Message From User : </label>
                        <?php echo e($message->msg_body); ?>

                    </div>

                    <div class="form-group">
                        <label for="">Message</label>
                        <textarea required name="msg" placeholder="Reply Message..." cols="30" rows="10" class="form-control"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success btn-block">Send</button>
                </form>
                <hr>
                <a href="<?php echo e(route('message.index')); ?>" class="btn btn-warning btn-block">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>