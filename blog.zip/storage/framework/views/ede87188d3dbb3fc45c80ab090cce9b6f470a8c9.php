<?php $__env->startSection('content'); ?>
    
<h1 class="page-header">Profile</h1>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Edit Profile Password
            </div>
            <div class="panel-body">
                <form action="<?php echo e(route('password.update')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Old Password</label>
                        <input name="old_password" type="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input name="new_password" type="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label><br>
                        <input name="confirm_password" type="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-lg btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>