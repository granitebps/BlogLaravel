<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <p>Website MyMind Membuat Post Baru Yang Berjudul <?php echo e($post); ?></p>
    <p>Link Untuk Langsung Menuju Post : https://localhost:8000/post/<?php echo e($slug); ?> </p>
</body>
</html>