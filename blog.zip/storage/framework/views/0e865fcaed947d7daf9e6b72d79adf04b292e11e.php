<?php $__env->startSection('content'); ?>
    <h1 class="page-header">Post</h1>
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Post List</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Post Title</th>
                                <th>Category</th>
                                <th>Tag</th>
                                <th>Created At</th>
                                <th colspan="2" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($post->count() > 0): ?>

                            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->post_title); ?></td>
                                    <td width="150px"><?php echo e($row->category->category_name); ?></td>
                                    <td width="300px">
                                        <?php $__currentLoopData = $row->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag->tag_name. ', '); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td width="200px"><?php echo e($row->created_at); ?></td>
                                    <td width="100px" class="text-center"><a href="<?php echo e(route('post.edit', ['id'=>$row->post_id])); ?>" class="btn btn-primary">Edit</a></td>
                                    <td width="100px" class="text-center">
                                        <form action="<?php echo e(route('post.destroy', ['id'=>$row->post_id])); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger">Trash</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-danger">No Post Found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo e($post->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>