<?php $__env->startSection('content'); ?>

    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--top-padding">

        <div class="row narrow">
            <div class="col-full s-content__header" data-aos="fade-up">
                <h1 class="display-1 display-1--with-line-sep">Tag: <?php echo e($tag_name->tag_name); ?></h1>
            </div>
        </div>
        
        <div class="row entries-wrap add-top-padding wide">
            <div class="entries">

                
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="col-block">
                    
                    <div class="item-entry" data-aos="zoom-in">
                        <div class="item-entry__thumb">
                            <a href="<?php echo e(route('home.show', ['slug'=>$row->post_slug])); ?>" class="item-entry__thumb-link">
                                <img src="<?php echo e(asset('storage/images/posts/'.$row->featured)); ?>" 
                                    srcset="<?php echo e(asset('storage/images/posts/'.$row->featured)); ?> 1x, <?php echo e(asset('storage/images/posts/'.$row->featured)); ?> 2x" alt="">
                            </a>
                        </div>
        
                        <div class="item-entry__text">
                            <h1 class="item-entry__title"><a href="<?php echo e(route('home.show', ['slug'=>$row->post_slug])); ?>"><?php echo e($row->post_slug); ?></a></h1>
                                
                            <div class="item-entry__date">
                                <a href="<?php echo e(route('home.show', ['slug'=>$row->post_slug])); ?>"><?php echo e($row->created_at->toFormattedDateString()); ?></a>
                            </div>
                        </div>
                    </div> <!-- item-entry -->

                </article> <!-- end article -->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div> <!-- end entries -->
        </div> <!-- end entries-wrap -->

        <?php echo e($post->links()); ?>


    </section> <!-- end s-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>