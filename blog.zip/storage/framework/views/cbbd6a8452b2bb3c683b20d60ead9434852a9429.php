<?php $__env->startSection('content'); ?>
    <h1 class="page-heading">Tag</h1>
    <div class="row">
        <div class="panel panel-red">
            <div class="panel-heading">Edit Tag : <?php echo e($tag->tag_name); ?></div>
            <div class="panel-body">
                <form action="<?php echo e(route('tag.update', ['id'=>$tag->tag_id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label>Tag Name</label>
                        <input type="text" name="tag_name" class="form-control" value="<?php echo e($tag->tag_name); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>