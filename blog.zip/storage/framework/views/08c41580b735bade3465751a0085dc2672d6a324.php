<?php $__env->startSection('content'); ?>
    <div class="row">
        <h1 class="page-heading">Post</h1>
        <div class="panel panel-primary">
            <div class="panel-heading">Create Post</div>
            <div class="panel-body">
                <form action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Featured Image | Maks : 2MB</label>
                        <input type="file" name="featured" class="form-control-file">
                    </div>
                    <div class="form-group">
                        <label>Post Title</label>
                        <input type="text" name="post_title" class="form-control" placeholder="Post Title..." required value="<?php echo e($errors->isEmpty() ? '' : old('post_title')); ?>">
                    </div>
                    <div class="form-group">
                        <label>Post Content</label>
                        <textarea name="post_content" id='article-ckeditor' cols="30" rows="10"><?php echo e($errors->isEmpty() ? '' : old('post_content')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category_id" class="form-control">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->category_id); ?>"
                                    <?php if(!$errors->isEmpty() && $row->category_id == old('category_id')): ?>
                                        selected
                                    <?php endif; ?>    
                                ><?php echo e($row->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tag</label>
                        <input type="text" name="tag" class="form-control" placeholder="Tag..." value="<?php echo e($errors->isEmpty() ? '' : old('tag')); ?>">
                        <small class="form-text">
                            Pisahkan tag dengan koma (,)
                        </small>
                    </div>
                    <button type="submit" class="btn btn-success btn-block">Publish</button>
                </form>
                <hr>
                <a href="<?php echo e(route('post.index')); ?>" class="btn btn-warning btn-block">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var options = {
            filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
            filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
            height: '700px',
            extraPlugins: 'codesnippet,iframe',
        };
        CKEDITOR.replace( 'article-ckeditor', options);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>